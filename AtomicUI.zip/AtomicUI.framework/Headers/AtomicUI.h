//
//  AtomicUI.h
//  AtomicUI
//
//  Created by Gülenay Gül on 6.02.2020.
//  Copyright © 2020 OneFrame. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AtomicUI.
FOUNDATION_EXPORT double AtomicUIVersionNumber;

//! Project version string for AtomicUI.
FOUNDATION_EXPORT const unsigned char AtomicUIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AtomicUI/PublicHeader.h>


